//push front
//Given an array and an additional value, insert this value at the beginning of the array. Do this without using any built-in array methods.

function pushFront(arr, num) {
    for (var idx = arr.length - 1; idx >= 0; idx--) {
        arr[idx+1] = arr[idx];
    }
    arr[0] = num;
    return arr;
}

console.log(pushFront([2,3,4], 1))


//pop front
//Given an array, remove and return the value at the beginning of the array. Do this without using any built-in array methods except pop().


function popFront(arr) {
    var newArr = arr[0];
    for (var idx = 1; idx < arr.length; idx++) {
        arr[idx-1] = arr[idx];
    }
    arr.pop(); 
    return newArr;
}

console.log(popFront([1,2,3,4]))

//insert at
//Given an array, index, and additional value, insert the value into array at given index. Do this without using built-in array methods. You can think of pushFront(arr,val) as equivalent to insertAt(arr,0,val).

function insertAt(arr, num, idx) {
    for (var i = arr.length - 1; i >= idx; i--) {
        arr[i+1] = arr[i];
    }
    arr[idx] = num; 
    return arr;
}

console.log(insertAt([1,2,3], 5, 0))